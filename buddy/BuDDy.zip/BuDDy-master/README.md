# BuDDy

This is a copy of the BuDDy library obtained from the [BuDDy website](http://buddy.sourceforge.net/manual/main.html) that is
provisioned with CMakeLists.txt files so that BuDDy can be built on Windows with Visual Studio. The BuDDy version provisioned is 2.4.

 Currently works with Visual Studio 2017 RC.
